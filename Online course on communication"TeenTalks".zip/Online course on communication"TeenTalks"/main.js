const nav=document.querySelector('#nav')

const navBtn=document.querySelector('#nav-btn')

const navBtnImg=document.querySelector('#nav-btn-img')


navBtn.onclick=()=>{
    if(nav.classList.toggle('open')){
navBtnImg.src="./block-regular-24.png";
    }else{
        navBtnImg.src="./menu-regular-24.png";
    }
}