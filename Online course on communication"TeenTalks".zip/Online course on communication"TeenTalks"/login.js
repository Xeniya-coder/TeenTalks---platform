document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Остановить отправку формы

const loginButton = document.getElementById('loginBtn');
const btnText = document.getElementById('btnText');
const btnSpinner = document.getElementById('btnSpinner');
const form = document.getElementById('loginForm');

loginButton.disabled = true;
loginButton.classList.remove('success', 'error');
loginButton.style.transform = 'scale(0.98)';
btnText.textContent = 'Checking...';
btnSpinner.style.display = 'inline-block';

// Проверка логина
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Список пользователей прямо в коде
    const users = [
        { username: 'admin', password: '1234' },
        { username: 'user', password: 'password' }
    ];

    // Ищем пользователя
    const user = users.find(u => u.username === username && u.password === password);

setTimeout(() => {
  if (user) {
    loginButton.classList.add('success');
    btnText.textContent = 'Success!';
    btnSpinner.style.display = 'none';
    setTimeout(() => {
      window.location.href = 'index.html';
    }, 1000);
  } else {
    loginButton.classList.add('error');
    btnText.textContent = 'Try again';
    btnSpinner.style.display = 'none';
    document.getElementById('error').innerText = 'Неверный логин или пароль!';
    form.classList.add('shake');
    setTimeout(() => {
      form.classList.remove('shake');
    }, 500);
  }

  loginButton.disabled = false;
  loginButton.style.transform = 'scale(1)';
}, 1500);


	function showToast(message, success = false) {
    const toast = document.getElementById('toast');
    toast.innerText = message;
    toast.style.backgroundColor = success ? '#4CAF50' : '#f44336'; // зелёный для успеха, красный для ошибки
    toast.className = "toast show";
    setTimeout(() => {
        toast.className = toast.className.replace("show", "");
    }, 3000);
}
	const togglePassword = document.getElementById('togglePassword');
	const passwordInput = document.getElementById('password');

    togglePassword.addEventListener('click', function () {
    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordInput.setAttribute('type', type);
    this.classList.toggle('bx-hide');
});

});